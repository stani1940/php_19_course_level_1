<footer>
  <p>Session project Homework online market</p>
</footer>
    </body>
</html>